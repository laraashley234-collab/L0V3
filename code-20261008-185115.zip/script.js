const navButtons = document.querySelectorAll('[data-view]');
const viewNames = {home:'Home',browser:'Browser',media:'Media player',games:'Mini games',code:'Code lab',terminal:'Mini terminal',lumi:'Lumi',settings:'Settings'};
function showView(name){
  if(!viewNames[name]) return;
  document.querySelectorAll('.view').forEach(view=>view.classList.toggle('active',view.id===`view-${name}`));
  document.querySelectorAll('.nav-item[data-view]').forEach(button=>button.classList.toggle('active',button.dataset.view===name));
  document.getElementById('crumb').textContent=viewNames[name];
  if(name==='code') runPreview();
}
navButtons.forEach(button=>button.addEventListener('click',()=>showView(button.dataset.view)));

const themeButtons = document.querySelectorAll('[data-theme-choice]');
function setTheme(theme){
  const dark=theme==='dark';
  document.body.classList.toggle('dark',dark);
  themeButtons.forEach(button=>button.classList.toggle('selected',button.dataset.themeChoice===theme));
  document.querySelector('.theme-quick').textContent=dark?'☀':'☾';
  try{localStorage.setItem('l0v3-theme',theme)}catch(error){}
}
let savedTheme='light';
try{savedTheme=localStorage.getItem('l0v3-theme')||'light'}catch(error){}
setTheme(savedTheme);
themeButtons.forEach(button=>button.addEventListener('click',()=>setTheme(button.dataset.themeChoice)));
document.querySelector('.theme-quick').addEventListener('click',()=>setTheme(document.body.classList.contains('dark')?'light':'dark'));

// Embedded browsing is subject to each website's iframe and security policies.
const browserForm=document.getElementById('browser-form');
const browserUrl=document.getElementById('browser-url');
const browserStage=document.getElementById('browser-stage');
let browserHistory=[];let browserIndex=-1;
function normalizeUrl(value){
  let url=value.trim();
  if(!url)return '';
  if(!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(url)) url=url.includes('.')&&!url.includes(' ')?`https://${url}`:`https://www.google.com/search?q=${encodeURIComponent(url)}`;
  return url;
}
function navigateBrowser(value,addHistory=true){
  const url=normalizeUrl(value);if(!url)return;
  browserUrl.value=url;
  if(addHistory){browserHistory=browserHistory.slice(0,browserIndex+1);browserHistory.push(url);browserIndex=browserHistory.length-1;}
  const frame=document.createElement('iframe');frame.title='Browsing window';frame.referrerPolicy='no-referrer';frame.setAttribute('sandbox','allow-forms allow-scripts allow-popups');frame.src=url;
  browserStage.replaceChildren(frame);
}
browserForm.addEventListener('submit',event=>{event.preventDefault();navigateBrowser(browserUrl.value)});
document.querySelectorAll('[data-url]').forEach(button=>button.addEventListener('click',()=>navigateBrowser(button.dataset.url)));
document.getElementById('browser-back').addEventListener('click',()=>{if(browserIndex>0){browserIndex--;navigateBrowser(browserHistory[browserIndex],false)}});
document.getElementById('browser-forward').addEventListener('click',()=>{if(browserIndex<browserHistory.length-1){browserIndex++;navigateBrowser(browserHistory[browserIndex],false)}});
document.getElementById('browser-reload').addEventListener('click',()=>{if(browserIndex>=0)navigateBrowser(browserHistory[browserIndex],false)});

const mediaPlayer=document.getElementById('media-player');
document.getElementById('media-url-form').addEventListener('submit',event=>{
  event.preventDefault();const url=document.getElementById('media-url').value.trim();if(!url)return;
  mediaPlayer.src=url;mediaPlayer.classList.add('loaded');mediaPlayer.load();
  document.getElementById('media-name').textContent=url.split('/').pop().split('?')[0]||'Your media';
  document.getElementById('media-subtitle').textContent='A little something you picked';
});
document.getElementById('media-file').addEventListener('change',event=>{
  const file=event.target.files[0];if(!file)return;
  if(mediaPlayer.dataset.objectUrl)URL.revokeObjectURL(mediaPlayer.dataset.objectUrl);
  const objectUrl=URL.createObjectURL(file);mediaPlayer.dataset.objectUrl=objectUrl;mediaPlayer.src=objectUrl;mediaPlayer.classList.add('loaded');mediaPlayer.load();
  document.getElementById('media-name').textContent=file.name;document.getElementById('media-subtitle').textContent='Playing from your device';
});

const editorIds=['html-code','css-code','js-code'];
function runPreview(){
  const html=document.getElementById('html-code').value;
  const css=document.getElementById('css-code').value.replace(/<\/style/gi,'<\\/style');
  const js=document.getElementById('js-code').value.replace(/<\/script/gi,'<\\/script');
  document.getElementById('code-preview').srcdoc=`<!doctype html><html><head><meta charset="utf-8"><style>${css}</style></head><body>${html}<script>${js}<\/script></body></html>`;
}
document.getElementById('run-code').addEventListener('click',runPreview);
editorIds.forEach(id=>document.getElementById(id).addEventListener('keydown',event=>{
  if(event.key==='Tab'){event.preventDefault();const field=event.currentTarget,start=field.selectionStart,end=field.selectionEnd;field.value=field.value.slice(0,start)+'  '+field.value.slice(end);field.selectionStart=field.selectionEnd=start+2;}
}));

const commandHelp='help, clear, date, echo <text>, about, games, tools';
const terminalOutput=document.getElementById('terminal-output');
function printTerminal(text,kind='term-response'){
  const line=document.createElement('div');line.className=`term-line ${kind}`;line.textContent=text;terminalOutput.appendChild(line);terminalOutput.scrollTop=terminalOutput.scrollHeight;
}
document.getElementById('terminal-form').addEventListener('submit',event=>{
  event.preventDefault();const input=document.getElementById('terminal-input');const command=input.value.trim();if(!command)return;
  printTerminal(`guest@l0v3 › ${command}`,'term-command');input.value='';const [name,...args]=command.split(/\s+/);const rest=args.join(' ');
  switch(name.toLowerCase()){
    case 'help':printTerminal(`Available commands: ${commandHelp}`);break;
    case 'clear':terminalOutput.innerHTML='';break;
    case 'date':printTerminal(new Date().toLocaleString());break;
    case 'echo':printTerminal(rest||'');break;
    case 'about':printTerminal('L0V3 Browser is your cozy little web nook. This terminal is a safe simulation.');break;
    case 'games':printTerminal('Try a quick round in the Mini games tab: memory, number guess, or rock paper scissors!');break;
    case 'tools':printTerminal('Browser · Media player · Mini games · Code lab · Mini terminal · Lumi · Settings');break;
    default:printTerminal(`I don't know “${name}”. Type help to see the available commands.`);
  }
});
document.getElementById('clear-terminal').addEventListener('click',()=>{terminalOutput.innerHTML='';});

const gameData=[
  {id:'clicker',name:'Heart tap',emoji:'♡',desc:'Tap your way to 10 hearts'},
  {id:'guess',name:'Number guess',emoji:'🔢',desc:'Find the secret number'},
  {id:'rps',name:'Rock paper scissors',emoji:'✊',desc:'Can you beat Lumi?'},
  {id:'memory',name:'Memory match',emoji:'🧠',desc:'Find all the matching pairs'},
  {id:'ttt',name:'Tic-tac-toe',emoji:'❎',desc:'Get three in a row'},
  {id:'reaction',name:'Quick reflex',emoji:'⚡',desc:'Test your reaction time'},
  {id:'color',name:'Color pick',emoji:'🎨',desc:'Find the color that matches'},
  {id:'whack',name:'Star pop',emoji:'⭐',desc:'Pop stars before time runs out'},
  {id:'coin',name:'Coin flip',emoji:'🪙',desc:'Call it: heads or tails'},
  {id:'math',name:'Quick sums',emoji:'➕',desc:'Solve a tiny math puzzle'}
];
const gameGrid=document.getElementById('game-grid');
const gamePanel=document.getElementById('game-play-panel');
let gameTimer=null;let gameState={};
gameGrid.innerHTML=gameData.map(game=>`<button class="game-choice" data-game="${game.id}"><span class="game-emoji">${game.emoji}</span><span><strong>${game.name}</strong><small>${game.desc}</small></span></button>`).join('');
gameGrid.addEventListener('click',event=>{const button=event.target.closest('[data-game]');if(button)startGame(button.dataset.game)});
function gameShell(title,description,body){
  gamePanel.innerHTML=`<div class="game-content"><div class="eyebrow">A QUICK LITTLE GAME</div><h2>${title}</h2><p>${description}</p>${body}<div class="game-feedback" id="game-feedback"></div></div>`;
}
function feedback(message){const node=document.getElementById('game-feedback');if(node)node.textContent=message;}
function startGame(id){
  clearInterval(gameTimer);gameTimer=null;gameState={};
  document.querySelectorAll('.game-choice').forEach(button=>button.classList.toggle('selected',button.dataset.game===id));
  const info=gameData.find(game=>game.id===id);if(!info)return;
  switch(id){
    case 'clicker':gameState.score=0;gameShell(info.name,'Tap the heart ten times to fill your love meter!',`<div class="game-score" id="game-score">0 / 10 hearts</div><button class="game-action" id="heart-tap" style="font-size:25px;padding:14px 24px">♡</button>`);break;
    case 'guess':gameState.secret=Math.floor(Math.random()*20)+1;gameShell(info.name,'I picked a number from 1 to 20. Can you find it?',`<form id="guess-form"><input class="game-answer" id="guess-input" type="number" min="1" max="20" placeholder="1 to 20" required/> <button class="game-action">Guess</button></form>`);break;
    case 'rps':gameShell(info.name,'Choose your move. First one to win a round gets the bragging rights!',`<div class="rps-options"><button class="game-action" data-rps="rock">✊ Rock</button> <button class="game-action" data-rps="paper">✋ Paper</button> <button class="game-action" data-rps="scissors">✌️ Scissors</button></div><div class="game-score" id="rps-score">You 0 — 0 Lumi</div>`);gameState.you=0;gameState.lumi=0;break;
    case 'memory':gameState.cards=['🌷','🌙','⭐','🍓','🌷','🌙','⭐','🍓'].sort(()=>Math.random()-.5);gameState.open=[];gameState.matched=[];gameShell(info.name,'Find all four matching pairs.',`<div class="game-board memory-board">${gameState.cards.map((_,i)=>`<button data-memory="${i}">?</button>`).join('')}</div><div class="game-score" id="memory-score">0 / 4 pairs</div>`);break;
    case 'ttt':gameState.board=Array(9).fill('');gameShell(info.name,'You are X. Get three in a row before O does.',`<div class="game-board ttt-board">${gameState.board.map((_,i)=>`<button data-cell="${i}"></button>`).join('')}</div><button class="game-action secondary" id="ttt-reset">New round</button>`);break;
    case 'reaction':gameState.status='ready';gameShell(info.name,'Click the button when it turns green. Don’t jump the gun!',`<button class="game-action" id="reaction-button">Start when ready</button><div class="game-score" id="reaction-score"></div>`);break;
    case 'color':gameState.colors=['#d87691','#6e9db1','#dcaa54','#927db7'];gameState.answer=gameState.colors[Math.floor(Math.random()*gameState.colors.length)];gameShell(info.name,`Pick the color <b>${gameState.answer}</b>.`, `<div class="color-options">${gameState.colors.slice().sort(()=>Math.random()-.5).map(color=>`<button data-color="${color}" style="background:${color}" aria-label="Choose color"></button>`).join('')}</div><button class="game-action secondary" id="color-new">New colors</button>`);break;
    case 'whack':gameState.score=0;gameState.time=15;gameState.active=-1;gameShell(info.name,'Pop the star whenever it appears. How many can you get in 15 seconds?',`<div class="game-score" id="whack-time">15 seconds · 0 stars</div><div class="game-board whack-board">${Array.from({length:9},(_,i)=>`<button data-whack="${i}">·</button>`).join('')}</div><button class="game-action" id="whack-start">Start popping</button>`);break;
    case 'coin':gameShell(info.name,'Call heads or tails, then flip your lucky coin!',`<button class="game-action" data-coin="Heads">Heads</button> <button class="game-action" data-coin="Tails">Tails</button><div class="game-score" id="coin-result">Make your call!</div>`);break;
    case 'math':makeMathGame();break;
  }
}
function makeMathGame(){gameState.a=Math.floor(Math.random()*9)+2;gameState.b=Math.floor(Math.random()*9)+1;gameState.answer=gameState.a+gameState.b;gameShell('Quick sums','What’s the answer? No calculator needed!',`<div class="game-score" style="font-size:22px">${gameState.a} + ${gameState.b} = ?</div><form id="math-form"><input class="game-answer" id="math-input" type="number" placeholder="Your answer" required/> <button class="game-action">Check</button></form><button class="game-action secondary" id="math-new">New sum</button>`)}
function gameResult(message){feedback(message)}
gamePanel.addEventListener('click',event=>{
  const button=event.target.closest('button');if(!button)return;
  if(button.id==='heart-tap'){gameState.score++;document.getElementById('game-score').textContent=`${gameState.score} / 10 hearts`;if(gameState.score>=10){button.disabled=true;gameResult('You filled the meter with love! ♡')}return}
  if(button.dataset.rps){const yours=button.dataset.rps,options=['rock','paper','scissors'],theirs=options[Math.floor(Math.random()*3)];if(yours===theirs)gameResult(`You both picked ${theirs}—it’s a tie!`);else if((yours==='rock'&&theirs==='scissors')||(yours==='paper'&&theirs==='rock')||(yours==='scissors'&&theirs==='paper')){gameState.you++;gameResult(`You picked ${yours}, Lumi picked ${theirs}. You win!`)}else{gameState.lumi++;gameResult(`You picked ${yours}, Lumi picked ${theirs}. Lumi wins this one!`)}document.getElementById('rps-score').textContent=`You ${gameState.you} — ${gameState.lumi} Lumi`;return}
  if(button.dataset.memory!==undefined){const i=Number(button.dataset.memory);if(gameState.matched.includes(i)||gameState.open.includes(i)||gameState.open.length>=2)return;button.textContent=gameState.cards[i];gameState.open.push(i);if(gameState.open.length===2){const [a,b]=gameState.open;if(gameState.cards[a]===gameState.cards[b]){gameState.matched.push(a,b);gameState.open=[];document.getElementById('memory-score').textContent=`${gameState.matched.length/2} / 4 pairs`;if(gameState.matched.length===8)gameResult('All pairs found! You have a lovely memory. ♡')}else setTimeout(()=>{gameState.open.forEach(index=>{const card=gamePanel.querySelector(`[data-memory="${index}"]`);if(card)card.textContent='?'});gameState.open=[]},650)}return}
  if(button.dataset.cell!==undefined){const index=Number(button.dataset.cell);if(gameState.board[index]||checkTicTacToe())return;gameState.board[index]='X';button.textContent='X';if(checkTicTacToe())return;const empty=gameState.board.map((v,i)=>v?null:i).filter(v=>v!==null);if(empty.length){const cpu=empty[Math.floor(Math.random()*empty.length)];gameState.board[cpu]='O';gamePanel.querySelector(`[data-cell="${cpu}"]`).textContent='O';checkTicTacToe()}return}
  if(button.id==='ttt-reset'){startGame('ttt');return}
  if(button.id==='reaction-button'){if(gameState.status==='ready'){button.textContent='Wait for green…';button.disabled=false;gameState.status='waiting';gameTimer=setTimeout(()=>{if(!document.getElementById('reaction-button'))return;gameState.started=Date.now();gameState.status='go';button.textContent='CLICK NOW!';button.style.background='#76ae83';button.disabled=false},900+Math.random()*2400)}else if(gameState.status==='waiting'){clearTimeout(gameTimer);gameState.status='ready';button.textContent='Too soon! Try again';button.disabled=false}else if(gameState.status==='go'){const time=Date.now()-gameState.started;gameState.status='ready';button.style.background='';button.textContent='Play again';document.getElementById('reaction-score').textContent=`Your reaction time: ${time} ms`}}
  if(button.dataset.color){gameResult(button.dataset.color===gameState.answer?'Perfect match! You’ve got a great eye. ✨':'Not that one—try another!');if(button.dataset.color===gameState.answer)gamePanel.querySelectorAll('[data-color]').forEach(item=>item.disabled=true);return}
  if(button.id==='color-new'){startGame('color');return}
  if(button.id==='whack-start'){gameState.score=0;gameState.time=15;button.disabled=true;button.textContent='Go!';gameState.active=Math.floor(Math.random()*9);updateWhack();gameTimer=setInterval(()=>{gameState.time--;if(gameState.time<=0){clearInterval(gameTimer);gameTimer=null;gameState.active=-1;updateWhack();button.disabled=false;button.textContent='Play again';gameResult(`Time! You popped ${gameState.score} stars. ✨`);return}gameState.active=Math.floor(Math.random()*9);updateWhack()},850);return}
  if(button.dataset.whack!==undefined&&Number(button.dataset.whack)===gameState.active&&gameState.time>0){gameState.score++;gameState.active=-1;updateWhack();return}
  if(button.dataset.coin){const result=Math.random()<.5?'Heads':'Tails';const node=document.getElementById('coin-result');node.textContent=`${result}! ${result===button.dataset.coin?'You called it! ✨':'So close—try again!'}`;return}
  if(button.id==='math-new'){makeMathGame();return}
});
gamePanel.addEventListener('submit',event=>{
  event.preventDefault();
  if(event.target.id==='guess-form'){const guess=Number(document.getElementById('guess-input').value);if(guess===gameState.secret){gameResult('You got it! A little brainpower goes a long way. ♡')}else gameResult(guess<gameState.secret?'A little higher…':'A little lower…');}
  if(event.target.id==='math-form'){const answer=Number(document.getElementById('math-input').value);if(answer===gameState.answer){gameResult('That’s right! Your brain is sparkling. ✨')}else gameResult('Not quite—give it another try!');}
});
function updateWhack(){const score=document.getElementById('whack-time');if(score)score.textContent=`${gameState.time} seconds · ${gameState.score} stars`;gamePanel.querySelectorAll('[data-whack]').forEach((button,i)=>{button.textContent=i===gameState.active?'⭐':'·';button.style.background=i===gameState.active?'var(--gold-pale)':''})}
function checkTicTacToe(){const lines=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];for(const [a,b,c] of lines){if(gameState.board[a]&&gameState.board[a]===gameState.board[b]&&gameState.board[a]===gameState.board[c]){gameResult(`${gameState.board[a]==='X'?'You win':'Lumi wins'}! Tap New round to play again.`);return true}}if(gameState.board.every(Boolean)){gameResult('A little draw! Tap New round to play again.');return true}return false}

const chatMessages=document.getElementById('chat-messages');
function addChat(text,who){const row=document.createElement('div');row.className=`chat-message ${who==='user'?'user-message':'lumi-message'}`;const avatar=document.createElement('span');avatar.className='message-avatar';avatar.textContent=who==='user'?'L':'✧';const bubble=document.createElement('div');const message=document.createElement('p');message.textContent=text;const time=document.createElement('small');time.textContent='Just now';bubble.append(message,time);row.append(avatar,bubble);chatMessages.appendChild(row);chatMessages.scrollTop=chatMessages.scrollHeight;}
function lumiReply(message){const text=message.toLowerCase();if(/show|tour|around|where/.test(text))return 'You can browse in Browser, play something in Mini games, make a page in Code lab, or bring a file to the Media player. Your settings let you switch to midnight blue, too! ♡';if(/encourag|sad|hard|tired|stressed|help/.test(text))return 'You’re doing better than you think. Take a breath, be kind to yourself, and remember: one little step is still a step. I’m cheering for you. ♡';if(/what can|do you do|who are you|what are you/.test(text))return 'I’m Lumi, your friendly guide around this little browser nook! I can point out features, offer encouragement, or help you choose what to explore next. I run locally in this demo.';if(/game|play|bored/.test(text))return 'A tiny game sounds lovely! Open Mini games and pick from ten little breaks—Heart tap, Memory match, Star pop, and more. ✨';if(/hello|hi|hey/.test(text))return 'Hello, lovely! I hope your day has a little sparkle in it. What would you like to explore? ♡';if(/thank/.test(text))return 'You’re so welcome! I’m happy to keep you company. ✨';if(/dark|theme|color|setting/.test(text))return 'Open Settings to choose Blush & gold or Midnight blue. You can also tap the moon in the top corner for a quick theme switch.';return 'That’s lovely to share with me. I’m a small local demo, so I can help with browser features, games, and a little encouragement. What would you like to explore? ♡'}
function sendChat(text){const message=text.trim();if(!message)return;addChat(message,'user');setTimeout(()=>addChat(lumiReply(message),'lumi'),350)}
document.getElementById('chat-form').addEventListener('submit',event=>{event.preventDefault();const input=document.getElementById('chat-input');sendChat(input.value);input.value=''});
document.querySelector('.suggestion-row').addEventListener('click',event=>{const button=event.target.closest('button');if(button)sendChat(button.textContent)});

document.getElementById('code-preview').srcdoc='<!doctype html><html><body style="font:14px system-ui;color:#777;text-align:center;padding:3rem">Click “Run preview” to see your page.</body></html>';
